void GBCC(int , int , double* , double* , int , int , double* , double* );
void GBCC(int , int , double* , double* , double* , int , int , double* , double* );

void GBCR(int , int , double* , double* , int , double* , double* );
void GBCR(int , int , double* , double* , double* , int , double* , double* );

void GBCP(int , int , double* , double* , int , int , double* , double* );
void GBCP(int , int , double* , double* , double* , int , int , double* , double* );